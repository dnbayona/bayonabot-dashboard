import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

export default function BayonaBotDashboard() {
  const [balance, setBalance] = useState(0);
  const [equity, setEquity] = useState(0);
  const [openTrades, setOpenTrades] = useState([]);
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState("");

  useEffect(() => {
    if (!authenticated) return;
    const fetchData = async () => {
      setBalance(200.0);
      setEquity(200.94);
      setOpenTrades([
        { pair: "EURUSD", type: "BUY", lot: 0.01, price: 1.08504, pnl: 0.94 },
      ]);
    };
    fetchData();
  }, [authenticated]);

  const handleLogin = () => {
    if (password === "Lorenza2025.") {
      setAuthenticated(true);
    } else {
      alert("Contraseña incorrecta");
    }
  };

  if (!authenticated) {
    return (
      <div className="p-6 max-w-md mx-auto">
        <h1 className="text-xl font-bold mb-4">Acceso al Dashboard BayonaBot</h1>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Ingresa la contraseña"
          className="border p-2 w-full mb-4"
        />
        <Button className="w-full" onClick={handleLogin}>Ingresar</Button>
      </div>
    );
  }

  return (
    <div className="p-6 grid gap-4">
      <h1 className="text-2xl font-bold">BayonaBot Dashboard</h1>
      <Card>
        <CardContent className="p-4">
          <p><strong>Balance:</strong> ${balance.toFixed(2)}</p>
          <p><strong>Equity:</strong> ${equity.toFixed(2)}</p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold mb-2">Operaciones Abiertas</h2>
          {openTrades.length === 0 ? (
            <p>No hay operaciones abiertas.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr>
                  <th>Par</th>
                  <th>Tipo</th>
                  <th>Lote</th>
                  <th>Precio</th>
                  <th>PnL</th>
                </tr>
              </thead>
              <tbody>
                {openTrades.map((trade, index) => (
                  <tr key={index} className="border-t">
                    <td>{trade.pair}</td>
                    <td>{trade.type}</td>
                    <td>{trade.lot}</td>
                    <td>{trade.price}</td>
                    <td>{trade.pnl >= 0 ? `+$${trade.pnl.toFixed(2)}` : `-$${Math.abs(trade.pnl).toFixed(2)}`}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <Button className="w-full">Actualizar datos</Button>
    </div>
  );
}
